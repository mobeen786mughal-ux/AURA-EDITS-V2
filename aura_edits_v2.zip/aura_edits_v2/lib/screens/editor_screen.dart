import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:ffmpeg_kit_flutter/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter/return_code.dart';
import 'package:path_provider/path_provider.dart';
import 'package:gal/gal.dart';
import '../widgets/tool_button.dart';

class EditorScreen extends StatefulWidget {
  final String filePath;
  final bool isVideo;
  const EditorScreen({super.key, required this.filePath, required this.isVideo});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  VideoPlayerController? _controller;
  
  double _speed = 1.0;
  double _volume = 1.0;
  double _rotation = 0.0;
  bool _flipHorizontal = false;
  String _overlayText = "";
  bool _isExporting = false;
  ColorFilter _colorFilter = const ColorFilter.mode(Colors.transparent, BlendMode.multiply);

  @override
  void initState() {
    super.initState();
    if (widget.isVideo) {
      _controller = VideoPlayerController.file(File(widget.filePath))
        ..initialize().then((_) {
          setState(() {});
          _controller!.play();
        });
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  Widget _buildMedia() {
    Widget mediaWidget;
    if (widget.isVideo && _controller != null && _controller!.value.isInitialized) {
      mediaWidget = VideoPlayer(_controller!);
    } else if (!widget.isVideo) {
      mediaWidget = Image.file(File(widget.filePath), fit: BoxFit.contain);
    } else {
      return const Center(child: CircularProgressIndicator(color: Colors.purpleAccent));
    }

    return Transform.scale(
      scaleX: _flipHorizontal ? -1.0 : 1.0,
      child: Transform.rotate(
        angle: _rotation,
        child: ColorFiltered(
          colorFilter: _colorFilter,
          child: Stack(
            alignment: Alignment.center,
            children: [
              mediaWidget,
              if (_overlayText.isNotEmpty)
                Text(_overlayText, style: const TextStyle(fontSize: 30, color: Colors.white, fontWeight: FontWeight.bold, backgroundColor: Colors.black45)),
            ],
          ),
        ),
      ),
    );
  }

  // === ASLI EXPORT FUNCTION ===
  Future<void> _exportVideo() async {
    if (!widget.isVideo) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Photo export coming soon!')));
      return;
    }

    setState(() => _isExporting = true);
    
    // FFmpeg command banayein
    String filters = "";
    
    // Rotate filter
    if (_rotation == 1.57) filters += "transpose=1,";
    else if (_rotation == 3.14) filters += "transpose=2,transpose=2,";
    
    // Flip filter
    if (_flipHorizontal) filters += "hflip,";
    
    // Speed filter (Audio + Video)
    String speedFilter = "";
    if (_speed != 1.0) {
      speedFilter = "-filter:v setpts=1/$_speed*PTS -filter:a atempo=$_speed";
    }

    // Text filter (Yahan font file ka path dena padta hai, Android ka default use kar rahe hain)
    if (_overlayText.isNotEmpty) {
      filters += "drawtext=text='$_overlayText':fontcolor=white:fontsize=48:x=(w-text_w)/2:y=(h-text_h)/2,";
    }

    // Filter string se aakhri comma hata dein
    if (filters.endsWith(",")) {
      filters = filters.substring(0, filters.length - 1);
    }

    String filterArg = filters.isNotEmpty ? "-vf \"$filters\"" : "";
    String command = "-i ${widget.filePath} $speedFilter $filterArg -c:v libx264 -preset ultrafast -c:a aac -y";

    // Output file ka path
    final Directory tempDir = await getTemporaryDirectory();
    String outputPath = "${tempDir.path}/aura_export_${DateTime.now().millisecondsSinceEpoch}.mp4";

    command += " $outputPath";

    // FFmpeg run karein
    await FFmpegKit.executeAsync(command, (session) async {
      final returnCode = await session.getReturnCode();

      if (ReturnCode.isSuccess(returnCode)) {
        // Video Gallery mein save karein
        await Gal.putVideo(outputPath);
        
        setState(() => _isExporting = false);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Video Exported Successfully to Gallery! ✅'),
            backgroundColor: Colors.green,
          ));
        }
      } else {
        // Error aane par log check karein
        setState(() => _isExporting = false);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Export Failed! Check video format. ❌'),
            backgroundColor: Colors.red,
          ));
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text('Aura Editor V3.0'),
        actions: [
          _isExporting 
            ? const Padding(padding: EdgeInsets.all(16.0), child: CircularProgressIndicator(color: Colors.purpleAccent))
            : TextButton(
                onPressed: _exportVideo, 
                child: const Text('Export', style: TextStyle(color: Colors.purpleAccent, fontWeight: FontWeight.bold))
              )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 3,
            child: Container(
              color: Colors.black,
              child: Center(child: _buildMedia()),
            ),
          ),
          if (widget.isVideo && _controller != null && _controller!.value.isInitialized)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(icon: Icon(_controller!.value.isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.white), 
                  onPressed: () { setState(() { _controller!.value.isPlaying ? _controller!.pause() : _controller!.play(); }); }),
              ],
            ),
          Container(
            height: 100,
            color: const Color(0xFF1E1E1E),
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.all(10),
              children: [
                ToolButton(icon: Icons.speed, title: 'Speed', onTap: () => _showSlider('Speed', _speed, 0.5, 2.0, (val) { setState(() { _speed = val; _controller?.setPlaybackSpeed(val); }); })),
                ToolButton(icon: Icons.volume_up, title: 'Volume', onTap: () => _showSlider('Volume', _volume, 0.0, 1.0, (val) { setState(() { _volume = val; _controller?.setVolume(val); }); })),
                ToolButton(icon: Icons.rotate_right, title: 'Rotate', onTap: () => setState(() => _rotation += 1.57)),
                ToolButton(icon: Icons.flip, title: 'Flip', onTap: () => setState(() => _flipHorizontal = !_flipHorizontal)),
                ToolButton(icon: Icons.color_lens, title: 'Filter', onTap: () => setState(() {
                  _colorFilter = _colorFilter == const ColorFilter.mode(Colors.transparent, BlendMode.multiply) 
                      ? const ColorFilter.mode(Colors.redAccent, BlendMode.modulate) 
                      : const ColorFilter.mode(Colors.transparent, BlendMode.multiply);
                })),
                ToolButton(icon: Icons.text_fields, title: 'Text', onTap: _addText),
              ],
            ),
          ),
          const Expanded(
            flex: 1,
            child: Center(child: Text('Real Export Engine Active', style: TextStyle(color: Colors.grey))),
          ),
        ],
      ),
    );
  }

  void _showSlider(String title, double currentVal, double min, double max, Function(double) onChanged) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E1E),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: const EdgeInsets.all(20),
              height: 150,
              child: Column(
                children: [
                  Text(title, style: const TextStyle(color: Colors.white, fontSize: 18)),
                  Slider(
                    value: currentVal, min: min, max: max, activeColor: Colors.purpleAccent,
                    onChanged: (val) {
                      setModalState(() { currentVal = val; });
                      onChanged(val);
                    },
                  ),
                ],
              ),
            );
          }
        );
      },
    );
  }

  void _addText() {
    TextEditingController textCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text('Add Text', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: textCtrl,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(hintText: 'Enter text...', hintStyle: TextStyle(color: Colors.grey)),
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() => _overlayText = textCtrl.text);
              Navigator.pop(context);
            },
            child: const Text('Add', style: TextStyle(color: Colors.purpleAccent)),
          )
        ],
      ),
    );
  }
}
