import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'editor_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> pickMedia(BuildContext context, bool isVideo) async {
    final ImagePicker picker = ImagePicker();
    final XFile? file = isVideo 
        ? await picker.pickVideo(source: ImageSource.gallery)
        : await picker.pickImage(source: ImageSource.gallery);
    
    if (file != null && context.mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (context) => EditorScreen(filePath: file.path, isVideo: isVideo)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Aura Edits V2.0'), backgroundColor: Colors.transparent, elevation: 0),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.auto_awesome, size: 100, color: Colors.purpleAccent),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: () => pickMedia(context, true),
              icon: const Icon(Icons.video_library),
              label: const Text('Import Video'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purpleAccent, padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15)),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () => pickMedia(context, false),
              icon: const Icon(Icons.photo),
              label: const Text('Import Photo'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent, padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15)),
            ),
          ],
        ),
      ),
    );
  }
}
